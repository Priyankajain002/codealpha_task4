# 🛡️ CodeAlpha Network Intrusion Detection System (NIDS)

This project is part of **Task 4** of the **CodeAlpha Cyber Security Internship**.  
It demonstrates how to set up and configure a basic Network Intrusion Detection System using **Snort**.

---

## 📌 Objective

- Monitor network traffic for malicious activity
- Detect threats using custom Snort rules

---

## 🧰 Tools Used

- Snort (Open Source NIDS)
- Linux (Ubuntu recommended)
- Optional: Wireshark, Nmap for testing

---

## ⚙️ Setup Instructions

### 🔹 Step 1: Install Snort

```bash
sudo apt update
sudo apt install snort
```

During setup:
- Set `HOME_NET` to your subnet (e.g., 192.168.1.0/24)
- Choose the correct interface (e.g., eth0, enp0s3)

You can also manually set it in `/etc/snort/snort.conf`:

```bash
ipvar HOME_NET 192.168.1.0/24
```

---

### 🔹 Step 2: Add a Custom Rule

Add this to `local.rules` (found at `/etc/snort/rules/local.rules`):

```snort
alert icmp any any -> any any (msg:"ICMP Packet Detected"; sid:1000001; rev:1;)
```

---

### 🔹 Step 3: Run Snort in NIDS Mode

```bash
sudo snort -A console -q -c /etc/snort/snort.conf -i eth0
```

Replace `eth0` with your network interface.

---

### 🔹 Step 4: Simulate Intrusion

Run a ping in another terminal:

```bash
ping 8.8.8.8
```

Expected Output:
```
[**] [1:1000001:1] ICMP Packet Detected [**]
```

---

### 🔹 Step 5: Additional Rule Example

```snort
alert tcp any any -> any 80 (msg:"Nmap Scan Detected"; flags:S; threshold:type threshold, track by_src, count 10, seconds 60; sid:1000002; rev:1;)
```

---

## 📂 Files Included

- `icmp_rule.rules` → Custom rule for ICMP packet detection
- `README.md` → Documentation

---

## 🏁 Status

✅ Task 4 Complete  
🔐 Intrusion Detection Configured using Snort  
🚀 Submitted as part of CodeAlpha Cyber Security Internship
